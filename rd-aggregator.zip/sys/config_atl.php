<?php
$FFMPEGURL="http://mojobase.com";

//$json=file_get_contents($FFMPEGURL."/cdb/ecg/?func=font");
//echo $json;
$FFMPEG_FONT_ARR=array("ADINEKIR.ttf","ADLER.ttf","AETHER3.ttf","AIFRAGME.ttf","AIRCUT.ttf","ALDO6.ttf","ALDOM2.ttf","ALIENATI.ttf","ALIENSAT.ttf","ARBONNIE.ttf","ARCena.ttf","ARDestine.ttf","Adresack.ttf","Adventure.ttf","Arial.ttf","Arista.ttf","AristaLight.ttf","BEECH.ttf","BlackBlocBoldItal.ttf","Bookman.ttf","DaysLater28.ttf","DigitRegular.ttf","Dumb2.ttf","Dumb3.ttf","Ebrima.ttf","Font1942.ttf","GO123.ttf","GoldenEye007.ttf","Harabara.ttf","HighwayToHell.ttf","HomeBoy.ttf","MVBoli.ttf","MagnetoBold.ttf","MedievalQueen.ttf","Pages32.ttf","RuggedRide.ttf","SansationBold.ttf","Shaman.ttf","SwordThrasher.ttf","TOYZARUX.ttf","Times.ttf","Trebuc.ttf","Verdana.ttf","aftermat.ttf","airmoleq.ttf","airmoles.ttf","jlrlilbittires.ttf","pricedownbl.ttf"
);

$JVZ_URL="https://www.jvzoo.com/";

//$key="AIzaSyBjghBtlS03EEwa9gY7fhN112mEXlDULe4";
//$res=json_decode(file_get_contents("https://www.googleapis.com/youtube/v3/videoCategories?part=snippet&regionCode=US&key=".$key),true);
//$YOUTUBE_CAT_ARR=array("1"=>"Film & Animation","2"=>"Autos & Vehicles","10"=>"Music","15"=>"Pets & Animals","17"=>"Sports","18"=>"Short Movies","19"=>"Travel & Events","20"=>"Gaming","21"=>"Videoblogging","22"=>"People & Blogs","23"=>"Comedy","24"=>"Entertainment","25"=>"News & Politics","26"=>"Howto & Style","27"=>"Education","28"=>"Science & Technology","29"=>"Nonprofits & Activism","30"=>"Movies","31"=>"Anime/Animation","32"=>"Action/Adventure","33"=>"Classics","34"=>"Comedy","35"=>"Documentary","36"=>"Drama","37"=>"Family","38"=>"Foreign","39"=>"Horror","40"=>"Sci-Fi/Fantasy","41"=>"Thriller","42"=>"Shorts","43"=>"Shows","44"=>"Trailers");
$YOUTUBE_CAT_ARR=array("1"=>"Film & Animation","2"=>"Autos & Vehicles","10"=>"Music","15"=>"Pets & Animals","17"=>"Sports","19"=>"Travel & Events","20"=>"Gaming","22"=>"People & Blogs","23"=>"Comedy","24"=>"Entertainment","25"=>"News & Politics","26"=>"Howto & Style","27"=>"Education","28"=>"Science & Technology","29"=>"Nonprofits & Activism");

$YOUTUBE_ST_ARR=array("public"=>"Public","private"=>"Private","unlisted"=>"Unlisted");

$GTAG_ARR=array("%kw%","%kw% review","%kw% reviews","%kw% overview","%kw% bonus","%kw% bonuses","%kw% buy","%kw% code","%kw% discount","%kw% launch","%kw% demo","%kw% demo video","%kw% course","%kw% software","%kw% explained","%kw% walkthrough","%kw% review plus bonus","%kw% best bonus","%kw% free","%kw% alternative","%kw% support","%kw% pro","%kw% honest review","%kw% oto","%kw% upsells","%kw% early bird","%kw% funnel","%kw% thoughts","%kw% scam","%kw% refund","%kw% coupon code","%kw% coupon","%kw% offer","does %kw% work","is %kw% good","is %kw% worth it","should i buy %kw%","download %kw%","get %kw%","find %kw%","buy %kw%","what is %kw%","how to get %kw%","how to use %kw%","how to buy %kw%","%kw% tutorial","%kw% help","%kw% support");
?>