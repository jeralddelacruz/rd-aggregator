<?php
	// CPANEL CREDENTIALS
	$cPanel_username = "newscascade";
	$cPanel_password = "simpapimpa8945";
	$cPanel_host_subdomain = "volare.websitewelcome.com";
?>