<div id="theme-3-alert">
    <div class="alert alert-dismissible show au-alert au-alert--70per" role="alert">
        <i class="zmdi"></i>
        <span class="content">
            <!-- MESSAGE SUCCESS/ERROR WILL APPEND HERE -->
        </span>
        <button class="close" type="button" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">
                <i class="zmdi zmdi-close-circle"></i>
            </span>
        </button>
    </div>
</div>