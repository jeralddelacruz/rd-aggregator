<div class="noti-wrap">
    <div class="noti__item js-item-menu">
        <i class="zmdi zmdi-notifications"></i>
        <span class="mes_num quantity d-none"></span>
        <div class="mess-dropdown js-dropdown">
            <div class="mes_body"></div>
            <div class="notifi__footer">
                <a href="index.php?cmd=mes">All notifications</a>
            </div>
        </div>
    </div>
</div>