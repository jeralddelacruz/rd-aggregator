<header class="header-desktop">
    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <div class="header-wrap">
                <div class="form-header"></div>
                <div class="header-button">
                    <?php include("notifications.php"); ?>
                    <?php include("account.php"); ?>
                </div>
            </div>
        </div>
    </div>
</header>