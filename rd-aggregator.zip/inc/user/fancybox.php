<link rel="stylesheet" href="../js/fancybox/jquery.fancybox.css" />
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.10.4/jquery-ui.min.js"></script>
<script src="../js/jquery-ui-timepicker-addon.min.js"></script>
<script src="../js/fancybox/jquery.fancybox.js"></script>