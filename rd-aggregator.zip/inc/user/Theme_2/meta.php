<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=0" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

<title><?php echo $index_title." &lsaquo; ".$WEBSITE["sitename"]." &ndash; ";?>Member CP</title>

<?php if ($WEBSITE["icon"]) : ?>
<link rel="shortcut icon" href="../img/<?php echo $WEBSITE["icon"] . "?v=" . rand(1, 1000);?>" />
<?php endif; ?>