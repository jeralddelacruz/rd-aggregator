<!DOCTYPE html>
<html lang="en">

<head>
    <?php include_once('meta.php'); ?>
    
    <?php include_once('css.php'); ?>
</head>

<body class="animsition">
    <div class="page-wrapper">
        <div class="page-content--bge5">
            <div class="container h-100 d-flex align-items-center">
         