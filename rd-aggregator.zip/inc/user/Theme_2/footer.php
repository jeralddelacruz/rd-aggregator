                </div>
            </section>
            <section>
                <div class="container-fluid">
                    <!--<div class="row">-->
                    <!--    <footer class="m-auto">-->
                    <!--        <div class="row">-->
                    <!--            <div class="col-lg-12">-->
                    <!--                <?php if (sizeof($FOOTER)) : ?>-->
                    <!--                <ul class="list-unstyled">-->
                    <!--                    <?php foreach ($FOOTER as $link) : ?>-->
                    <!--                    <li><a href="index.php?cmd=page&id=<?php echo $link["page_id"];?>"><?php echo $link["page_title"];?></a></li>-->
                    <!--                    <?php endforeach; ?>-->
                    <!--                </ul>-->
                    <!--                <?php endif; ?>-->
                    <!--            </div>-->
                    <!--        </div>-->
                    <!--    </footer>-->

                    <!--    <div class="col-md-12">-->
                    <!--        <p class="copyright">&copy; <?php echo date("Y")." ".$WEBSITE["sitename"];?>. All rights reserved.</p>-->
                    <!--    </div>-->
                  
                    </div>
                </div>
            </section>
            <!-- END PAGE CONTAINER-->
        </div>
    </div>

    <?php include('scripts.php'); ?>

    <?php include('mess.php'); ?>
        
</body>

</html>