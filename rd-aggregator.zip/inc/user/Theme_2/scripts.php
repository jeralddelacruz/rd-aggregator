<!-- Bootstrap JS-->
<script src="/themes/vendor/bootstrap-4.1/popper.min.js"></script>
<script src="/themes/vendor/bootstrap-4.1/bootstrap.min.js"></script>
<!-- Vendor JS       -->
<script src="/themes/vendor/slick/slick.min.js"></script>
<script src="/themes/vendor/wow/wow.min.js"></script>
<script src="/themes/vendor/animsition/animsition.min.js"></script>
<script src="/themes/vendor/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
<script src="/themes/vendor/counter-up/jquery.waypoints.min.js"></script>
<script src="/themes/vendor/counter-up/jquery.counterup.min.js"></script>
<script src="/themes/vendor/circle-progress/circle-progress.min.js"></script>
<script src="/themes/vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
<script src="/themes/vendor/chartjs/Chart.bundle.min.js"></script>
<script src="/themes/vendor/select2/select2.min.js"></script>
<script src="/themes/vendor/vector-map/jquery.vmap.js"></script>
<script src="/themes/vendor/vector-map/jquery.vmap.min.js"></script>
<script src="/themes/vendor/vector-map/jquery.vmap.sampledata.js"></script>
<script src="/themes/vendor/vector-map/jquery.vmap.world.js"></script>

<!-- Main JS-->
<script src="/themes/js/main.js?v=<?php echo rand(1, 1000); ?>"></script>
