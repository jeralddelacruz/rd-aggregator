<div class="row">
	<div class="col-md-12">
		<div class="alert alert-warning">You don't have access to this Feature.</div>
	</div>
	<div class="col-md-12">
		<a href="index.php?cmd=renew"><div class="btn btn-<?php echo $WEBSITE["theme_btn"];?> btn-fill pull-right">Upgrade Membership</div></a>
	</div>
</div>