<h2><?php echo $index_title;?></h2>
<p><a href="http://www.screencast.com/t/afSwEI2VL" target="_blank">W+ Payment Processor Setup</a></p>
<p><a href="http://www.screencast.com/t/un75PFheT" target="_blank">JVZoo Payment Processor Setup</a></p>